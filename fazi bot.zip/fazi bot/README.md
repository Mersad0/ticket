# Ticket System | With Reactions
Hello Guys 🖐

This is Discord Ticket Bot Using Reaction Use And Enjoy IT! 🧨


## install
```
- [discord.js] npm install discord.js
- [dateformat] npm install dateformat
- [quick.db]npm install quick.db
- [fs] npm install fs
- [path] npm install path 
```
- Insert bot token in Storage>config.js 

- open start.bat 

- and Enjoy! 🕺

 ## Problem
- Contact IccY#0569 For Any issues or Question

- And Also Dont Forget To join My Discord!
https://discord.gg/2AepY62ZXM
